% from rotation matrix to cubochoric

function q = om2cu(om)

q = ho2cu(om2ho(om));