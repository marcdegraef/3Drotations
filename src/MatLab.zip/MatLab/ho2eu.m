% from homochoric to Euler angles

function q = ho2eu(h)

q = ax2eu(ho2ax(h));