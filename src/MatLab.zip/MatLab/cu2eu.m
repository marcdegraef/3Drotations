% from cubochoric to Euler angles

function q = cu2eu(c)

q = ho2eu(cu2ho(c));